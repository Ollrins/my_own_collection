# Ansible Collection Submission: my_own_namespace.yandex_cloud_elk

##  Collection Information
- **Namespace**: my_own_namespace
- **Collection**: yandex_cloud_elk  
- **Version**: 1.0.0
- **Module**: my_own_module
- **Role**: my_file_role

##  Module Purpose
Creates a text file on a remote host with specified content. The module is **idempotent** - it only makes changes if the file doesn't exist or content differs.

## 📋 Module Parameters
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| path | str |  Yes | Absolute path to the file |
| content | str |  Yes | Content to write to the file |

##  Role Variables
| Variable | Default | Description |
|----------|---------|-------------|
| my_file_role_path | /tmp/default_file_from_role.txt | Path to the file |
| my_file_role_content | "Default content from role" | Content of the file |

##  Installation
```bash
ansible-galaxy collection install my_own_namespace-yandex_cloud_elk-1.0.0.tar.gz
 Usage Examples
Using Module Directly
yaml
- name: Create configuration file
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/config.txt
    content: |
      setting1=value1
      setting2=value2
Using Role
yaml
- name: Use my_file_role
  hosts: localhost
  vars:
    my_file_role_path: /tmp/custom_file.txt
    my_file_role_content: "Custom content"
  roles:
    - my_file_role
 Verification Steps Completed
Step 4 - Local Module Test 
Command:

bash
ANSIBLE_LIBRARY=./library ansible -m my_own_module -a 'path=/tmp/test.txt content="Hello"' localhost
Result: File created successfully

Step 6 - Idempotence Test 
First run: changed=true (file created)

Second run: changed=false (no changes) → IDEMPOTENT

Step 15 - Collection Installation 
bash
ansible-galaxy collection install my_own_namespace-yandex_cloud_elk-1.0.0.tar.gz
Result: Installed successfully to ~/.ansible/collections/

Step 16 - Final Test with Installed Collection 
Module test: test_collection_working.yml - passes with idempotence

Role test: test_role.yml - passes with idempotence

 Test Output Highlights
Second run showing idempotence:

text
TASK [Second run - same file]
ok: [localhost] => {"changed": false, ...}
 Collection Structure
text
my_own_namespace.yandex_cloud_elk/
├── galaxy.yml
├── README.md
├── plugins/
│   └── modules/
│       └── my_own_module.py
├── roles/
│   └── my_file_role/
│       ├── defaults/
│       │   └── main.yml
│       └── tasks/
│           └── main.yml
├── test_collection_working.yml
└── test_role.yml

Status:  SUBMISSION READY
Date: 2026-04-18
